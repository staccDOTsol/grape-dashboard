export default class UserWallet {
    userId: string;
    address: string;
}