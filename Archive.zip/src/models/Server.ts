export default class Server{
    serverId: string;
    name: string;
    logo: string;
    url: string;
    registered: boolean;
    twitter: string;
}