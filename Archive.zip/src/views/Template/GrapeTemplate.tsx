import * as React from 'react';

import {
  Grid,
} from '@mui/material';

import { makeStyles, styled, alpha, useTheme } from '@mui/material/styles';

// THIS IS A SIMPLY COMPONENT TEMPLATE... START BUILDING!

export function TemplateView(props: any) {
  
  React.useEffect(()=>{
    //do some magic here
  },[])


  return (
    <Grid>
      Grape Template
    </Grid>
  );
}
