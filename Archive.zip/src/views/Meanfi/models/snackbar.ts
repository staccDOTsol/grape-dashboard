import { AlertColor } from "@mui/material/Alert";

export interface SnackBarMessageProps {
    message: string;
    severity: AlertColor;
}
